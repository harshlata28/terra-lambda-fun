def hello(event, context):
    print("welcome to hello world--terraform")
    